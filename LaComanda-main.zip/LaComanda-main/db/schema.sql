CREATE TABLE ordenes (
    id_orden INT(11) PRIMARY KEY AUTO_INCREMENT,
    mesa_id INT(11) NOT NULL,
    id_estado INT(11) NOT NULL DEFAULT 1,
    total DECIMAL(10, 2) NOT NULL DEFAULT 0,
    id_usuario INT(11),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    hora_entrega DATETIME
);

CREATE TABLE detalle_orden (
    id_detalle INT(11) PRIMARY KEY AUTO_INCREMENT,
    id_orden INT(11) NOT NULL,
    id_producto INT(11) NOT NULL,
    cantidad INT(11) NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL
);
