<?php
class Conexion
{
    public static function conectar()
    {
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $user = getenv('DB_USER') ?: 'root';
        $password = getenv('DB_PASSWORD');
        if ($password === false) {
            $password = '';
        }
        $database = getenv('DB_NAME') ?: 'la_comanda';
        $port = (int)(getenv('DB_PORT') ?: 3306);

        $conexion = new mysqli($host, $user, $password, $database, $port);

        if ($conexion->connect_error) {
            die("Error de conexión: " . $conexion->connect_error);
        }

        $conexion->set_charset("utf8");
        return $conexion;
    }
}

$conexion = Conexion::conectar();
