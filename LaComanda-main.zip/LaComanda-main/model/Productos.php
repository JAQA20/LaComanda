<?php
require_once __DIR__ . "/Conexion.php";

class Productos
{
    private static function columnasDisponibles($conexion, $tabla)
    {
        $columnas = [];
        $res = $conexion->query("SHOW COLUMNS FROM {$tabla}");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $columnas[] = $row['Field'];
            }
        }
        return $columnas;
    }

    // Para el CRUD admin (tabla/lista)
    public static function listar()
    {
        $conexion = Conexion::conectar();

        $colsProductos = self::columnasDisponibles($conexion, 'productos');
        $colsCategorias = self::columnasDisponibles($conexion, 'categorias');

        $selectIcono = in_array('icono', $colsProductos, true) ? "p.icono" : "'fa-mug-hot' AS icono";
        $selectActivo = in_array('activo', $colsProductos, true) ? "p.activo" : "1 AS activo";
        $selectCategoriaSlug = in_array('slug', $colsCategorias, true)
            ? "c.slug AS categoria_slug"
            : "LOWER(REPLACE(c.nombre, ' ', '-')) AS categoria_slug";

        $sql = "
            SELECT p.id, p.nombre, p.precio, {$selectIcono}, {$selectActivo},
                   p.categoria_id, c.nombre AS categoria_nombre, {$selectCategoriaSlug}
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            ORDER BY p.id DESC
        ";

        $result = $conexion->query($sql);
        if (!$result) throw new Exception("Error al listar productos: " . $conexion->error);

        $productos = [];
        while ($row = $result->fetch_assoc()) $productos[] = $row;
        return $productos;
    }

    // Para llenar el <select> de categorías en crear/editar
    public static function listarCategoriasActivas()
    {
        $conexion = Conexion::conectar();
        $colsCategorias = self::columnasDisponibles($conexion, 'categorias');

        $selectSlug = in_array('slug', $colsCategorias, true)
            ? "slug"
            : "LOWER(REPLACE(nombre, ' ', '-')) AS slug";
        $where = in_array('activo', $colsCategorias, true) ? "WHERE activo = 1" : "";
        $order = in_array('orden', $colsCategorias, true) ? "ORDER BY orden ASC, nombre ASC" : "ORDER BY nombre ASC";

        $sql = "SELECT id, nombre, {$selectSlug} FROM categorias {$where} {$order}";
        $result = $conexion->query($sql);
        if (!$result) throw new Exception("Error al listar categorías: " . $conexion->error);

        $cats = [];
        while ($row = $result->fetch_assoc()) $cats[] = $row;
        return $cats;
    }

    // Para el INDEX (productos por slug)
    public static function listarPorCategoriaSlug($slug)
    {
        $conexion = Conexion::conectar();
        $slug = trim($slug);

                $colsProductos = self::columnasDisponibles($conexion, 'productos');
                $colsCategorias = self::columnasDisponibles($conexion, 'categorias');

        if ($slug === "" || $slug === "mesas") return [];

                $whereSlug = in_array('slug', $colsCategorias, true)
                        ? "c.slug = ?"
                        : "LOWER(REPLACE(c.nombre, ' ', '-')) = ?";
                $whereCatActiva = in_array('activo', $colsCategorias, true) ? "AND c.activo = 1" : "";
                $whereProdActivo = in_array('activo', $colsProductos, true) ? "AND p.activo = 1" : "";
                $selectIcono = in_array('icono', $colsProductos, true) ? "p.icono" : "'fa-mug-hot' AS icono";

        $stmt = $conexion->prepare("
                        SELECT p.id, p.nombre, p.precio, {$selectIcono}
            FROM productos p
            INNER JOIN categorias c ON c.id = p.categoria_id
                        WHERE {$whereSlug}
                            {$whereCatActiva}
                            {$whereProdActivo}
            ORDER BY p.nombre ASC
        ");
        if (!$stmt) throw new Exception("Error prepare listarPorCategoriaSlug: " . $conexion->error);

        $stmt->bind_param("s", $slug);
        $stmt->execute();
        $res = $stmt->get_result();

        $items = [];
        while ($row = $res->fetch_assoc()) $items[] = $row;
        return $items;
    }

    public static function obtenerPorId($id)
    {
        $conexion = Conexion::conectar();
        $id = (int)$id;

        $stmt = $conexion->prepare("
            SELECT id, categoria_id, nombre, precio, icono, activo
            FROM productos
            WHERE id = ?
            LIMIT 1
        ");
        if (!$stmt) throw new Exception("Error prepare obtenerPorId: " . $conexion->error);

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();

        return $res->fetch_assoc() ?: null;
    }

    public static function nombreExisteEnCategoria($nombre, $categoria_id, $exceptoId = null)
    {
        $conexion = Conexion::conectar();
        $nombre = trim($nombre);
        $categoria_id = (int)$categoria_id;

        if ($exceptoId !== null) {
            $exceptoId = (int)$exceptoId;
            $stmt = $conexion->prepare("
                SELECT id
                FROM productos
                WHERE nombre = ?
                  AND categoria_id = ?
                  AND id <> ?
                LIMIT 1
            ");
            if (!$stmt) throw new Exception("Error prepare nombreExisteEnCategoria: " . $conexion->error);
            $stmt->bind_param("sii", $nombre, $categoria_id, $exceptoId);
        } else {
            $stmt = $conexion->prepare("
                SELECT id
                FROM productos
                WHERE nombre = ?
                  AND categoria_id = ?
                LIMIT 1
            ");
            if (!$stmt) throw new Exception("Error prepare nombreExisteEnCategoria: " . $conexion->error);
            $stmt->bind_param("si", $nombre, $categoria_id);
        }

        $stmt->execute();
        $res = $stmt->get_result();
        return $res->num_rows > 0;
    }

    public static function crear($categoria_id, $nombre, $precio, $icono, $activo)
    {
        $conexion = Conexion::conectar();

        $categoria_id = (int)$categoria_id;
        $nombre = trim($nombre);
        $precio = (int)$precio;
        $icono = trim($icono);
        $activo = (int)$activo;

        if ($categoria_id <= 0 || $nombre === "" || $precio <= 0) {
            throw new Exception("Debe completar todos los campos obligatorios.");
        }

        // Validación simple del icono (para evitar basura)
        if ($icono === "") $icono = "fa-mug-hot";

        if (self::nombreExisteEnCategoria($nombre, $categoria_id)) {
            throw new Exception("Ya existe un producto con ese nombre en esta categoría.");
        }

        $stmt = $conexion->prepare("
            INSERT INTO productos (categoria_id, nombre, precio, icono, activo)
            VALUES (?, ?, ?, ?, ?)
        ");
        if (!$stmt) throw new Exception("Error prepare crear: " . $conexion->error);

        $stmt->bind_param("isisi", $categoria_id, $nombre, $precio, $icono, $activo);

        if (!$stmt->execute()) {
            throw new Exception("No se pudo crear el producto: " . $stmt->error);
        }

        return $stmt->insert_id;
    }

    public static function actualizar($id, $categoria_id, $nombre, $precio, $icono, $activo)
    {
        $conexion = Conexion::conectar();

        $id = (int)$id;
        $categoria_id = (int)$categoria_id;
        $nombre = trim($nombre);
        $precio = (int)$precio;
        $icono = trim($icono);
        $activo = (int)$activo;

        if ($id <= 0) throw new Exception("ID inválido.");
        if ($categoria_id <= 0 || $nombre === "" || $precio <= 0) {
            throw new Exception("Debe completar todos los campos obligatorios.");
        }
        if ($icono === "") $icono = "fa-mug-hot";

        if (self::nombreExisteEnCategoria($nombre, $categoria_id, $id)) {
            throw new Exception("Ya existe otro producto con ese nombre en esta categoría.");
        }

        $stmt = $conexion->prepare("
            UPDATE productos
            SET categoria_id = ?, nombre = ?, precio = ?, icono = ?, activo = ?
            WHERE id = ?
            LIMIT 1
        ");
        if (!$stmt) throw new Exception("Error prepare actualizar: " . $conexion->error);

        $stmt->bind_param("isisii", $categoria_id, $nombre, $precio, $icono, $activo, $id);

        if (!$stmt->execute()) {
            throw new Exception("No se pudo actualizar el producto: " . $stmt->error);
        }

        return true;
    }

    public static function eliminar($id)
    {
        $conexion = Conexion::conectar();
        $id = (int)$id;

        if ($id <= 0) throw new Exception("ID inválido.");

        $stmt = $conexion->prepare("DELETE FROM productos WHERE id = ? LIMIT 1");
        if (!$stmt) throw new Exception("Error prepare delete: " . $conexion->error);

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            throw new Exception("No se pudo eliminar el producto: " . $stmt->error);
        }

        if ($stmt->affected_rows === 0) {
            throw new Exception("No se encontró el producto para eliminar.");
        }

        return true;
    }
}
