<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . "/../model/Conexion.php";

$archivo = __DIR__ . "/ordenes.json";
$contenido = file_get_contents($archivo);
$ordenes = json_decode($contenido, true);

if (!is_array($ordenes)) $ordenes = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $mesa = $_POST["mesa"] ?? null;

    if (!$mesa) {
        echo json_encode(["status" => "ERROR", "mensaje" => "Mesa no recibida"]);
        exit;
    }

    foreach ($ordenes as &$orden) {
        if ($orden["mesa"] == $mesa && $orden["estado"] === "pendiente") {

            // Cambiar estado igual que cocina
            $orden["estado"] = "entregada";
            $orden["hora_entrega"] = date("H:i");
            break;
        }
    }
    unset($orden);

    file_put_contents($archivo, json_encode($ordenes, JSON_PRETTY_PRINT));

    // Actualizar también en DB (última orden pendiente de esa mesa)
    try {
        $cn = Conexion::conectar();

        $cols = [];
        $resCols = $cn->query("SHOW COLUMNS FROM ordenes");
        if ($resCols) {
            while ($row = $resCols->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }

        $idCol = in_array('id_orden', $cols, true) ? 'id_orden' : (in_array('id', $cols, true) ? 'id' : null);
        $mesaCol = in_array('mesa_id', $cols, true) ? 'mesa_id' : null;
        $estadoTexto = in_array('estado', $cols, true);
        $estadoId = in_array('id_estado', $cols, true);
        $horaEntregaCol = in_array('hora_entrega', $cols, true) ? 'hora_entrega' : null;
        $fechaOrdenCol = in_array('timestamp', $cols, true) ? 'timestamp' : (in_array('creado_en', $cols, true) ? 'creado_en' : (in_array('created_at', $cols, true) ? 'created_at' : $idCol));

        if ($idCol && $mesaCol) {
            $setParts = [];
            if ($estadoId) {
                $setParts[] = "id_estado = 3";
            }
            if ($estadoTexto) {
                $setParts[] = "estado = 'entregada'";
            }
            if ($horaEntregaCol) {
                $setParts[] = "{$horaEntregaCol} = NOW()";
            }

            if (!empty($setParts)) {
                $whereEstado = $estadoId ? "id_estado IN (1,2)" : ($estadoTexto ? "estado IN ('pendiente','en_proceso')" : "1=1");
                $sql = "UPDATE ordenes
                        SET " . implode(', ', $setParts) . "
                        WHERE {$idCol} = (
                            SELECT t.{$idCol} FROM (
                                SELECT {$idCol}
                                FROM ordenes
                                WHERE {$mesaCol} = ? AND {$whereEstado}
                                ORDER BY {$fechaOrdenCol} DESC
                                LIMIT 1
                            ) t
                        )";
                $stmt = $cn->prepare($sql);
                if ($stmt) {
                    $mesaInt = (int)$mesa;
                    $stmt->bind_param("i", $mesaInt);
                    $stmt->execute();
                }
            }
        }
    } catch (Throwable $e) {
        // No bloquear la entrega de UI por falla DB secundaria
    }

    echo json_encode(["status" => "OK"]);
    exit;
}

echo json_encode(["status" => "ERROR", "mensaje" => "Método no permitido"]);
