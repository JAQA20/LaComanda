<?php
return [
    'enabled' => true,
    'transport' => 'smtp',

    'smtp_host' => 'sandbox.smtp.mailtrap.io',
    'smtp_port' => 587,
    'smtp_username' => 'e849ecd31b2b87',
    'smtp_password' => '7aaf37bfeb9e1c',
    'smtp_encryption' => 'tls',

    'token' => '',
    'inbox_id' => '',
    'from_email' => 'no-reply@lacomanda.local',
    'from_name' => 'La Comanda',
    'endpoint_base' => 'https://sandbox.api.mailtrap.io/api/send/',
];
