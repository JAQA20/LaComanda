<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// DEBUG: confirmar ejecución
//file_put_contents(__DIR__ . "/debug.txt", "LLEGO\n", FILE_APPEND);

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../model/Conexion.php";

// Ruta del archivo de órdenes
$archivo = __DIR__ . "/ordenes.json";

// Crear archivo si no existe
if (!file_exists($archivo)) {
    file_put_contents($archivo, json_encode([]));
}

// Leer JSON actual
$contenido = file_get_contents($archivo);
$ordenes = json_decode($contenido, true);

// Si json_decode falla, reiniciar arreglo
if (!is_array($ordenes)) {
    $ordenes = [];
}

// Recibir JSON del fetch()
$input = file_get_contents("php://input");
//file_put_contents(__DIR__ . "/input_debug.txt", $input);

$data = json_decode($input, true);

// Validar entrada
if (!is_array($data)) {
    echo json_encode([
        "status" => "ERROR",
        "message" => "Datos inválidos",
        "debug" => $input
    ]);
    exit;
}

// Normalizar valores
$data["mesa"]  = isset($data["mesa"])  ? (string)$data["mesa"]  : "N/A";
$data["items"] = isset($data["items"]) ? (string)$data["items"] : "";
$data["total"] = isset($data["total"]) ? (float)$data["total"] : 0;
$itemsDetalle = isset($data["itemsDetalle"]) && is_array($data["itemsDetalle"]) ? $data["itemsDetalle"] : [];

// Generar número de orden consecutivo
$ultimoNumero = 0;
foreach ($ordenes as $o) {
    if (isset($o["numero"]) && is_numeric($o["numero"]) && $o["numero"] > $ultimoNumero) {
        $ultimoNumero = (int)$o["numero"];
    }
}
$numero = $ultimoNumero + 1;

// Completar orden
$data["numero"]    = $numero;
$data["estado"]    = "pendiente";
$data["timestamp"] = time();

// Agregar al arreglo
$ordenes[] = $data;

// DEBUG antes de guardar
//file_put_contents(__DIR__ . "/save_debug.txt", "----\n" . json_encode($ordenes) . "\n", FILE_APPEND);

// Guardar archivo actualizado
file_put_contents(
    $archivo,
    json_encode($ordenes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

// Guardar también en DB para historial/admin
try {
    $cn = Conexion::conectar();
    $cn->begin_transaction();

    $cols = [];
    $resCols = $cn->query("SHOW COLUMNS FROM ordenes");
    if ($resCols) {
        while ($row = $resCols->fetch_assoc()) {
            $cols[] = $row['Field'];
        }
    }

    $insertCols = [];
    $placeholders = [];
    $types = "";
    $vals = [];

    if (in_array('mesa_id', $cols, true)) {
        $insertCols[] = 'mesa_id';
        $placeholders[] = '?';
        $types .= 'i';
        $vals[] = (int)$data['mesa'];
    }
    if (in_array('id_estado', $cols, true)) {
        $insertCols[] = 'id_estado';
        $placeholders[] = '?';
        $types .= 'i';
        $vals[] = 1;
    } elseif (in_array('estado', $cols, true)) {
        $insertCols[] = 'estado';
        $placeholders[] = '?';
        $types .= 's';
        $vals[] = 'pendiente';
    }
    if (in_array('total', $cols, true)) {
        $insertCols[] = 'total';
        $placeholders[] = '?';
        $types .= 'd';
        $vals[] = (float)$data['total'];
    } elseif (in_array('monto_total', $cols, true)) {
        $insertCols[] = 'monto_total';
        $placeholders[] = '?';
        $types .= 'd';
        $vals[] = (float)$data['total'];
    }
    if (in_array('id_usuario', $cols, true) && isset($_SESSION['user_id'])) {
        $insertCols[] = 'id_usuario';
        $placeholders[] = '?';
        $types .= 'i';
        $vals[] = (int)$_SESSION['user_id'];
    }
    if (in_array('timestamp', $cols, true)) {
        $insertCols[] = 'timestamp';
        $placeholders[] = 'NOW()';
    }

    if (!empty($insertCols)) {
        $sqlIns = "INSERT INTO ordenes (" . implode(', ', $insertCols) . ") VALUES (" . implode(', ', $placeholders) . ")";
        $stmt = $cn->prepare($sqlIns);
        if (!$stmt) {
            throw new Exception("No se pudo preparar insert de orden: " . $cn->error);
        }

        if ($types !== "") {
            $stmt->bind_param($types, ...$vals);
        }

        if (!$stmt->execute()) {
            throw new Exception("No se pudo guardar la orden: " . $stmt->error);
        }

        $dbOrdenId = (int)$stmt->insert_id;

        // Insertar detalle si existe tabla y vienen items detallados
        $hasDetalle = (bool)$cn->query("SHOW TABLES LIKE 'detalle_orden'")->num_rows;
        if ($hasDetalle && $dbOrdenId > 0 && !empty($itemsDetalle)) {
            $stmtProd = $cn->prepare("SELECT id FROM productos WHERE nombre = ? LIMIT 1");
            $stmtDet = $cn->prepare("INSERT INTO detalle_orden (id_orden, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");

            foreach ($itemsDetalle as $item) {
                $nombre = trim((string)($item['nombre'] ?? ''));
                $cantidad = (int)($item['cantidad'] ?? 1);
                $precio = (float)($item['precio'] ?? 0);
                if ($nombre === '' || $cantidad <= 0) {
                    continue;
                }

                $stmtProd->bind_param('s', $nombre);
                $stmtProd->execute();
                $resProd = $stmtProd->get_result();
                $prod = $resProd ? $resProd->fetch_assoc() : null;
                if (!$prod) {
                    continue;
                }

                $idProducto = (int)$prod['id'];
                $stmtDet->bind_param('iiid', $dbOrdenId, $idProducto, $cantidad, $precio);
                $stmtDet->execute();
            }
        }
    }

    $cn->commit();
} catch (Throwable $e) {
    if (isset($cn) && $cn instanceof mysqli) {
        $cn->rollback();
    }
    http_response_code(500);
    echo json_encode([
        "status" => "ERROR",
        "message" => "No se pudo guardar la orden en base de datos",
        "detail" => $e->getMessage()
    ]);
    exit;
}

// Respuesta final al fetch
echo json_encode([
    "status" => "OK",
    "numero" => $numero
]);
exit;
