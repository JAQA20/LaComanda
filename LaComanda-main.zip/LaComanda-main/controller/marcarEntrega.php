<?php
require_once __DIR__ . "/../model/Conexion.php";

$archivo = __DIR__ . "/ordenes.json";

// Leer ordenes
$ordenes = file_exists($archivo)
    ? json_decode(file_get_contents($archivo), true)
    : [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $numero = isset($_POST["numero"]) ? intval($_POST["numero"]) : 0;
    $idOrden = isset($_POST["id_orden"]) ? intval($_POST["id_orden"]) : 0;
    $mesa = isset($_POST["mesa"]) ? intval($_POST["mesa"]) : 0;
    $esAjax = (
        (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
        (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) ||
        $idOrden > 0
    );

    // Buscar la orden y marcarla como entregada
    foreach ($ordenes as &$orden) {
        if ((isset($orden["numero"]) && $numero > 0 && $orden["numero"] == $numero) ||
            (isset($orden["numero"]) && $idOrden > 0 && $orden["numero"] == $idOrden)) {
            $orden["estado"] = "entregada";
            $orden["hora_entrega"] = date("H:i");
            break;
        }
    }

    // Guardar cambios en el archivo
    file_put_contents($archivo, json_encode($ordenes, JSON_PRETTY_PRINT));

    // Actualizar también en DB
    try {
        $cn = Conexion::conectar();
        $cols = [];
        $resCols = $cn->query("SHOW COLUMNS FROM ordenes");
        if ($resCols) {
            while ($row = $resCols->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }

        $idCol = in_array('id_orden', $cols, true) ? 'id_orden' : (in_array('id', $cols, true) ? 'id' : null);
        $mesaCol = in_array('mesa_id', $cols, true) ? 'mesa_id' : null;
        $estadoTexto = in_array('estado', $cols, true);
        $estadoId = in_array('id_estado', $cols, true);
        $horaEntregaCol = in_array('hora_entrega', $cols, true) ? 'hora_entrega' : null;
        $fechaOrdenCol = in_array('timestamp', $cols, true) ? 'timestamp' : (in_array('creado_en', $cols, true) ? 'creado_en' : (in_array('created_at', $cols, true) ? 'created_at' : $idCol));

        $setParts = [];
        if ($estadoId) $setParts[] = "id_estado = 3";
        if ($estadoTexto) $setParts[] = "estado = 'entregada'";
        if ($horaEntregaCol) $setParts[] = "{$horaEntregaCol} = NOW()";

        if ($idCol && !empty($setParts)) {
            if ($idOrden > 0) {
                $sql = "UPDATE ordenes SET " . implode(', ', $setParts) . " WHERE {$idCol} = ? LIMIT 1";
                $stmt = $cn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param('i', $idOrden);
                    $stmt->execute();
                }
            } elseif ($mesaCol && $mesa > 0) {
                $whereEstado = $estadoId ? "id_estado IN (1,2)" : ($estadoTexto ? "estado IN ('pendiente','en_proceso')" : "1=1");
                $sql = "UPDATE ordenes
                        SET " . implode(', ', $setParts) . "
                        WHERE {$idCol} = (
                            SELECT t.{$idCol} FROM (
                                SELECT {$idCol}
                                FROM ordenes
                                WHERE {$mesaCol} = ? AND {$whereEstado}
                                ORDER BY {$fechaOrdenCol} DESC
                                LIMIT 1
                            ) t
                        )";
                $stmt = $cn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param('i', $mesa);
                    $stmt->execute();
                }
            }
        }
    } catch (Throwable $e) {
        if ($esAjax) {
            http_response_code(500);
            echo json_encode(["status" => "ERROR", "message" => "No se pudo actualizar en DB"]);
            exit;
        }
    }

    if ($esAjax) {
        header("Content-Type: application/json; charset=utf-8");
        echo json_encode(["status" => "OK"]);
        exit;
    }

    header("Location: ../views/cocina.php");
    exit;
}

header("Content-Type: application/json; charset=utf-8");
http_response_code(405);
echo json_encode(["status" => "ERROR", "message" => "Método no permitido"]);
