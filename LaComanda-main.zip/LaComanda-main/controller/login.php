<?php
session_start();
header("Content-Type: application/json");

require_once __DIR__ . "/../db/conexion.php";

$email = $_POST["email"] ?? null;
$password = $_POST["password"] ?? null;

if (!$email || !$password) {
    echo json_encode([
        "status" => "ERROR",
        "message" => "Datos incompletos"
    ]);
    exit;
}

$sql = "SELECT id, nombre, email, password, rol_id 
        FROM usuarios 
        WHERE email = ? AND activo = 1 
        LIMIT 1";

$stmt = $conexion->prepare($sql);
$stmt->execute([$email]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    echo json_encode([
        "status" => "ERROR",
        "message" => "Usuario no encontrado"
    ]);
    exit;
}

/* ✅ VALIDACIÓN CON HASH BCRYPT */
if (!password_verify($password, $usuario["password"])) {
    echo json_encode([
        "status" => "ERROR",
        "message" => "Contraseña incorrecta"
    ]);
    exit;
}

/* ✅ CREAR SESIÓN */
$_SESSION["usuario_id"] = $usuario["id"];
$_SESSION["usuario_nombre"] = $usuario["nombre"];
$_SESSION["rol_id"] = $usuario["rol_id"];

echo json_encode([
    "status" => "OK"
]);
exit;
