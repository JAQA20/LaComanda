<?php
require_once __DIR__ . "/Conexion.php";

class Categorias
{
    private static function columnasDisponibles($cn)
    {
        $cols = [];
        $res = $cn->query("SHOW COLUMNS FROM categorias");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }
        return $cols;
    }

    public static function listarActivas()
    {
        $cn = Conexion::conectar();
        $cols = self::columnasDisponibles($cn);

        $selectSlug = in_array('slug', $cols, true)
            ? "slug"
            : "LOWER(REPLACE(nombre, ' ', '-')) AS slug";

        $selectIcono = in_array('icono', $cols, true)
            ? "icono"
            : "'fa-tags' AS icono";

        $where = in_array('activo', $cols, true) ? "WHERE activo = 1" : "";
        $order = in_array('orden', $cols, true) ? "ORDER BY orden ASC, nombre ASC" : "ORDER BY nombre ASC";

        $sql = "SELECT id, nombre, {$selectSlug}, {$selectIcono}
            FROM categorias
            {$where}
            {$order}";
        $res = $cn->query($sql);
        $data = [];
        while ($row = $res->fetch_assoc()) $data[] = $row;
        return $data;
    }

    public static function obtenerPorSlug($slug)
    {
        $cn = Conexion::conectar();
        $cols = self::columnasDisponibles($cn);

        $selectSlug = in_array('slug', $cols, true)
            ? "slug"
            : "LOWER(REPLACE(nombre, ' ', '-')) AS slug";

        $selectIcono = in_array('icono', $cols, true)
            ? "icono"
            : "'fa-tags' AS icono";

        $whereBy = in_array('slug', $cols, true)
            ? "slug = ?"
            : "LOWER(REPLACE(nombre, ' ', '-')) = ?";

        $sql = "SELECT id, nombre, {$selectSlug}, {$selectIcono}
            FROM categorias
            WHERE {$whereBy}
            LIMIT 1";
        $stmt = $cn->prepare($sql);
        $stmt->bind_param("s", $slug);
        $stmt->execute();
        $res = $stmt->get_result();
        return $res->fetch_assoc() ?: null;
    }
}
